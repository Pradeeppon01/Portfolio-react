import React from 'react'
import './Credits.css'

export default function Credits() {
  return (
        <div className='creditsContainer'>
          <p className='creditsPara'>Designed & Built by Pon pradeep.</p>
        </div>
  )
}