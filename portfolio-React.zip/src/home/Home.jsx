import Footer from './Footer'
import PostCard from './PostCard'
import Projects from './Projects'
import HireMe from './HireMe'
import InTouch from './InTouch'
import About from './About'
import Flip from './Flip'

export default function Home() {
  return (
    <div>
      <PostCard/>
      <Projects/>
      <HireMe/>
      <Footer/>
      <InTouch/>
      <Flip/>
      <About/>
    </div>
  )
}