import React from 'react'
import './HireMe.css'

function HireMe(){
  return(
    <>
      <div className='hireMeContainer'>
        <h2 className='hireMeText1'>Wanna Hire Me?</h2>
        <h3 className='hireMeText2'>Take a 👁️ at my CV..</h3>
        <a href="https://github.com/Pradeeppon01/Resume/blob/main/Pradeep%20react%20resume.pdf" target='_blank'><button className='cvButton'>Resume</button></a>
      </div>
    </>
  )
}
export default HireMe;