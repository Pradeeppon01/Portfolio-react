import React from 'react'
import image from './image.png'
import './Photo.css'

function Photo(){
  return(
    <div>
      <img className='photoPhoto'src={image}></img>
    </div>
  )
}
export default Photo;